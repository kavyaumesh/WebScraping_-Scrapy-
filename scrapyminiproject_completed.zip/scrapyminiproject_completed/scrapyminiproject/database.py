# -*- coding: utf-8 -*-
"""
Created on Sun Dec 20 22:07:54 2020

@author: Kavya Umesh Naik
"""

import sqlite3

conn= sqlite3.connect('myshopclue.db')
curr=conn.cursor()

#curr.execute("""create table shopclue_tb(
 #                           titles text,
  #                          prices text,
   #                         discounts text)""")
   
curr.execute("""insert into shopclue_tb(titles,
                                        prices,
                                        discounts) values('hii','hello','welcome')""",
            )
conn.commit()

conn.commit()
conn.close()