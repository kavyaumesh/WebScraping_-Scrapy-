import scrapy
from ..items import ScrapyminiprojectItem

class ShopcluesSpider(scrapy.Spider):
   #name of spider
   name = 'shopclues'

   #list of allowed domains
   allowed_domains = ['www.shopclues.com/']
   #starting url
   start_urls = ['https://www.shopclues.com/appliances-led-tvs.html?facet_display_resolution[]=UHD&fsrc=facet_display_resolution.html/',
                 'https://www.shopclues.com/kitchen-dining-dinner-sets.html/']
   #location of csv file
   custom_settings = {
       'FEED_URI' : 'tmp/shopigg.csv'
   }


   def parse(self, response):
       items = ScrapyminiprojectItem()
       #Extract product information
       titles = response.css('.prod_name::text').extract()
       prices = response.css('.p_price::text').extract()
       #prices=response.xpath('//span[contains(@class,"p_price")]/text()').extract()
       discounts = response.css('.prd_discount::text').extract()

       for item in zip(titles,prices,discounts):
               items['titles'] = item[0]
               items['prices'] = item[1]
               items['discounts'] = item[2]

               yield items
           
